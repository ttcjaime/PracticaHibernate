create
    definer = root@localhost function existeDisco(f_name varchar(50)) returns bit
BEGIN
RETURN EXISTS (
SELECT 1
FROM disco
WHERE nombre = f_name
);
END;

