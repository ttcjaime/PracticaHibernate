create
    definer = root@localhost function existeDiscografica(f_name varchar(50)) returns bit
BEGIN
RETURN EXISTS (
SELECT 1
FROM discografica
WHERE nombre = f_name
);
END;

