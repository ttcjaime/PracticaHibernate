create
    definer = root@localhost function existeArtista(f_name varchar(50)) returns bit
BEGIN
RETURN EXISTS (
SELECT 1
FROM artista
WHERE nombre = f_name
);
END;

